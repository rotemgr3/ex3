#### PART 1 ####
# final_grade: Calculates the final grade for each student, and writes the output (while eliminating illegal
# rows from the input file) into the file in `output_path`. Returns the average of the grades.
#   input_path: Path to the file that contains the input
#   output_path: Path to the file that will contain the output

def checkArgs(parameters):
    if parameters[0][0] == '0' or len(parameters[0]) != 8:
        return False
    if not (parameters[1].isalpha() or parameters[1] == ""):
        return False
    if int(parameters[2]) < 1:
        return False
    if int(parameters[3]) <= 50 or int(parameters[2]) > 100:
        return False
    return True

def final_grade(input_path: str, output_path: str) -> int:
    in_file = open(input_path, 'r')
    lines = in_file.readlines();
    in_file.close()

    students = {}
    for line in lines:
        line = line.replace(" ", "")
        parameters = line.split(",")
        if not checkArgs(parameters):
            continue
        key = int(parameters[0])
        student_grade = ((key % 100) + int(parameters[3])) // 2
        value = [int(parameters[3]), student_grade]
        students[key] = value

    out_file = open(output_path, 'w')
    class_avg = 0
    for key in sorted(students):
        class_avg += students[key][1]
        str_to_print = "{id}, {homework_avg}, {final_grade}\n".format(id=key, homework_avg=students[key][0], 
                                                                final_grade=students[key][1])
        out_file.write(str_to_print)
    out_file.close()

    return class_avg // len(students)


#### PART 2 ####
# check_strings: Checks if `s1` can be constructed from `s2`'s characters.
#   s1: The string that we want to check if it can be constructed
#   s2: The string that we want to construct s1 from
def check_strings(s1: str, s2: str) -> bool:
    s1 = s1.lower()
    s2 = s2.lower()

    for letter in s1:
        if s1.count(letter) > s2.count(letter):
            return False
    
    return True